Tests run with Vitest and Playwright. E2E expects dev server and API.

Unit:
```bash
pnpm test
```

E2E:
```bash
pnpm e2e
```

